<?php
const SERVERURL = "https://sistema.cersa.org.pe/";
const COMPANY = "SISTEMA CERSA";
date_default_timezone_set("America/Lima");

