<?php

const SERVER="localhost";
const DB="cersaorg_clientespotenciales";
const USER="cersaorg_joseluis";
const PASS="hSR4POe.7;aZ";

//SISTEMA GESTOR DE BASE DE DATOS
const SGBD="mysql:host=".SERVER.";dbname=".DB;


//no modificar
const METHOD="AES-256-CBC";

//modificar si se desea
const SECRET_KEY='$SC@2019';
const SECRET_IV='201926';