
<!--programacion de las altertas-->
<script src="vistas/js/main.js"></script>

<!--alertas-->
	<script src="vistas/js/jquery-3.1.1.min.js"></script>
	<script src="vistas/js/jquery.min.js"></script>
	<script src="vistas/js/sweetalert2.min.js"></script>
	<script src="vistas/js/main.js"></script>
	<script src="vistas/js/material.min.js"></script>
